ipaSim generic IPA tester checkpoint

Public validation order:
1. Run the repository workflow "Synthetic iOS IPA on Windows".
2. Require the bootstrap IPA checkpoint to execute through ipaSim on
   Windows and return guest X0=42.
3. Inspect the untouched native IPA and UIKit Hello World boundaries.
4. Run "Windows ARM64 Core" and require its semantic/core tests to pass.
5. Only after public synthetic/core checks pass, optionally run a private
   application locally with this package. Do not upload the private IPA,
   RuntimeRoot, or private application logs to public CI/issues.

Generic local method:
1. Extract this tester ZIP.
2. Drag any .ipa onto Test-Ipa.cmd.
3. Optionally supply an extracted iOS runtime root whose top level
   contains System and usr.

Loader-only command:
   Test-Ipa.cmd "C:\path\to\App.ipa"

Loader plus RuntimeRoot:
   Test-Ipa.cmd "C:\path\to\App.ipa" "C:\path\to\RuntimeRoot"

ipaSim does not package or download Apple runtime binaries. The iOS
Simulator runtime can import a macOS-host libSystem surface; the tester
carries IpaSimDarwinHost.dll only for host semantics with defensible
Windows equivalents. Unsupported behavior remains an explicit failure.

The generic local tester auto-detects the top-level .app and Mach-O
executable instead of encoding any application name or bundle path.
For public collaboration, reproduce failures with the synthetic fixtures
and share those logs instead of private application output.
